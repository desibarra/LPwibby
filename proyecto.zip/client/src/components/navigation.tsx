import { Button } from '@/components/ui/button';

export function Navigation() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="fixed top-0 w-full z-50 bg-wibby-dark/90 backdrop-blur-md border-b border-wibby-surface-light">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-4">
          <div className="flex items-center">
            <div className="text-2xl font-bold text-wibby-green">Wibby</div>
          </div>
          <div className="hidden md:flex space-x-8">
            <button 
              onClick={() => scrollToSection('beneficios')}
              className="text-wibby-text hover:text-wibby-green transition-colors"
            >
              Beneficios
            </button>
            <button 
              onClick={() => scrollToSection('funciones')}
              className="text-wibby-text hover:text-wibby-green transition-colors"
            >
              Cómo Funciona
            </button>
            <button 
              onClick={() => scrollToSection('demos')}
              className="text-wibby-text hover:text-wibby-green transition-colors"
            >
              Demos
            </button>
            <button 
              onClick={() => scrollToSection('testimonios')}
              className="text-wibby-text hover:text-wibby-green transition-colors"
            >
              Testimonios
            </button>
            <button 
              onClick={() => scrollToSection('contacto')}
              className="text-wibby-text hover:text-wibby-green transition-colors"
            >
              Contacto
            </button>
          </div>
          <Button 
            className="bg-wibby-green text-wibby-dark hover:bg-wibby-green/90 font-semibold hover:shadow-lg hover:shadow-wibby-green/30 transition-all duration-300 transform hover:scale-105"
            onClick={() => scrollToSection('demo-form')}
          >
            Solicitar Demo
          </Button>
        </div>
      </div>
    </nav>
  );
}
