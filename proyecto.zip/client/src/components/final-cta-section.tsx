import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { InteractiveBackground } from './interactive-background';

interface DemoFormData {
  name: string;
  email: string;
  company: string;
  phone: string;
  message: string;
}

export function FinalCtaSection() {
  const { toast } = useToast();
  const [formData, setFormData] = useState<DemoFormData>({
    name: '',
    email: '',
    company: '',
    phone: '',
    message: ''
  });

  const demoRequestMutation = useMutation({
    mutationFn: async (data: DemoFormData) => {
      const response = await apiRequest('POST', '/api/demo-request', data);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "¡Demo agendada!",
        description: "Te contactaremos pronto para coordinar tu demo gratuita.",
      });
      setFormData({
        name: '',
        email: '',
        company: '',
        phone: '',
        message: ''
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Hubo un problema al enviar tu solicitud. Inténtalo nuevamente.",
        variant: "destructive"
      });
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa al menos tu nombre y email.",
        variant: "destructive"
      });
      return;
    }
    demoRequestMutation.mutate(formData);
  };

  const handleInputChange = (field: keyof DemoFormData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section className="py-20 geometric-bg relative">
      <InteractiveBackground />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10 mb-16">
        <h2 className="text-4xl lg:text-6xl font-bold mb-6">
          ¿Listo para convertir tu WhatsApp en una{' '}
          <span className="text-wibby-green">máquina de ventas?</span>
        </h2>
        
        <p className="text-xl text-wibby-text mb-8 leading-relaxed">
          Deja de improvisar. La herramienta que tus clientes prefieren para comunicarse contigo merece una gestión profesional. Agenda una demo gratuita y te mostraremos en 15 minutos cómo Wibby puede multiplicar la eficiencia de tu equipo.
        </p>
      </div>

      {/* Demo Form */}
      <div id="demo-form" className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <Card className="bg-wibby-surface border-wibby-green/20">
          <CardContent className="p-8">
            <h3 className="text-2xl font-bold text-center mb-6 text-wibby-green">
              Agendar mi Demo Gratuita
            </h3>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name" className="text-wibby-text">Nombre *</Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => handleInputChange('name', e.target.value)}
                    className="bg-wibby-dark border-wibby-surface-light text-wibby-text"
                    placeholder="Tu nombre completo"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="email" className="text-wibby-text">Email *</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="bg-wibby-dark border-wibby-surface-light text-wibby-text"
                    placeholder="tu@empresa.com"
                    required
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="company" className="text-wibby-text">Empresa</Label>
                  <Input
                    id="company"
                    value={formData.company}
                    onChange={(e) => handleInputChange('company', e.target.value)}
                    className="bg-wibby-dark border-wibby-surface-light text-wibby-text"
                    placeholder="Nombre de tu empresa"
                  />
                </div>
                <div>
                  <Label htmlFor="phone" className="text-wibby-text">Teléfono</Label>
                  <Input
                    id="phone"
                    value={formData.phone}
                    onChange={(e) => handleInputChange('phone', e.target.value)}
                    className="bg-wibby-dark border-wibby-surface-light text-wibby-text"
                    placeholder="+34 600 000 000"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="message" className="text-wibby-text">Mensaje (opcional)</Label>
                <Textarea
                  id="message"
                  value={formData.message}
                  onChange={(e) => handleInputChange('message', e.target.value)}
                  className="bg-wibby-dark border-wibby-surface-light text-wibby-text"
                  placeholder="Cuéntanos sobre tu negocio y cómo usas WhatsApp actualmente..."
                  rows={4}
                />
              </div>

              <Button 
                type="submit"
                disabled={demoRequestMutation.isPending}
                className="w-full bg-wibby-green text-wibby-dark hover:bg-wibby-green/90 py-6 text-lg font-bold hover:shadow-2xl hover:shadow-wibby-green/40 transition-all duration-300 transform hover:scale-105"
              >
                {demoRequestMutation.isPending ? 'Enviando...' : 'Agendar mi Demo Gratuita'}
              </Button>
            </form>
            
            <p className="text-sm text-wibby-text-muted text-center mt-6">
              Tu competencia ya está buscando cómo optimizar. No te quedes atrás. Agenda hoy y recibe una auditoría gratuita de tu flujo actual de WhatsApp.
            </p>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
