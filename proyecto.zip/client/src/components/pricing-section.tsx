import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';

export function PricingSection() {
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        let { hours, minutes, seconds } = prev;
        
        if (seconds > 0) {
          seconds--;
        } else if (minutes > 0) {
          minutes--;
          seconds = 59;
        } else if (hours > 0) {
          hours--;
          minutes = 59;
          seconds = 59;
        }
        
        return { hours, minutes, seconds };
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="precios" className="py-20 relative z-10" style={{ background: 'transparent' }}>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        
        {/* Main Headline */}
        <div className="mb-8">
          <h2 className="text-6xl lg:text-8xl font-bold mb-4">
            <span className="text-wibby-green">Más del 75%</span>{' '}
            <span className="text-white">de Descuento</span>
          </h2>
          <h3 className="text-2xl lg:text-3xl font-semibold text-gray-300">
            Oferta de Lanzamiento - Solo por 24 Horas
          </h3>
        </div>

        {/* Scarcity Paragraph */}
        <p className="text-lg text-gray-300 mb-8 max-w-2xl mx-auto">
          Únete a los primeros 100 clientes y obtén acceso completo a Wibby con un precio exclusivo que no volverás a ver.
        </p>

        {/* Countdown Timer */}
        <div className="flex justify-center items-center gap-8 mb-12">
          <div className="text-center">
            <div className="text-6xl lg:text-7xl font-bold text-wibby-green countdown-digit">
              {String(timeLeft.hours).padStart(2, '0')}
            </div>
            <div className="text-sm lg:text-base text-gray-400 uppercase tracking-wider">
              HORAS
            </div>
          </div>
          
          <div className="text-4xl lg:text-5xl text-wibby-green font-bold">:</div>
          
          <div className="text-center">
            <div className="text-6xl lg:text-7xl font-bold text-wibby-green countdown-digit">
              {String(timeLeft.minutes).padStart(2, '0')}
            </div>
            <div className="text-sm lg:text-base text-gray-400 uppercase tracking-wider">
              MINUTOS
            </div>
          </div>
          
          <div className="text-4xl lg:text-5xl text-wibby-green font-bold">:</div>
          
          <div className="text-center">
            <div className="text-6xl lg:text-7xl font-bold text-wibby-green countdown-digit">
              {String(timeLeft.seconds).padStart(2, '0')}
            </div>
            <div className="text-sm lg:text-base text-gray-400 uppercase tracking-wider">
              SEGUNDOS
            </div>
          </div>
        </div>

        {/* Bonus Boxes */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <div className="bonus-box border border-gray-700 rounded-xl p-6 text-center">
            <div className="text-4xl mb-4">⭐</div>
            <h4 className="text-lg font-semibold text-white mb-2">Setup Gratuito</h4>
            <p className="text-gray-400">Valor: <span className="text-wibby-green font-bold">$150</span></p>
          </div>
          
          <div className="bonus-box border border-gray-700 rounded-xl p-6 text-center">
            <div className="text-4xl mb-4">🚀</div>
            <h4 className="text-lg font-semibold text-white mb-2">Acceso a IA Avanzada</h4>
            <p className="text-gray-400">Valor: <span className="text-wibby-green font-bold">$200</span></p>
          </div>
          
          <div className="bonus-box border border-gray-700 rounded-xl p-6 text-center">
            <div className="text-4xl mb-4">🎁</div>
            <h4 className="text-lg font-semibold text-white mb-2">Soporte Prioritario</h4>
            <p className="text-gray-400">Valor: <span className="text-wibby-green font-bold">$100</span></p>
          </div>
        </div>

        {/* Pricing Display */}
        <div className="mb-8">
          {/* Original Price (Crossed Out) */}
          <div className="text-3xl lg:text-4xl text-gray-500 line-through mb-2">
            $167/mes
          </div>
          
          {/* Final Price (Highlighted) */}
          <div className="text-7xl lg:text-8xl font-bold text-wibby-green mb-4 pricing-highlight">
            $37<span className="text-4xl">/mes</span>
          </div>
          
          {/* Offer Clarification */}
          <p className="text-lg text-gray-300">
            Asegura este precio especial para siempre. Oferta por tiempo limitado.
          </p>
        </div>

        {/* CTA Button */}
        <div className="mb-8">
          <Button 
            className="bg-wibby-green text-wibby-dark hover:bg-wibby-green/90 px-12 py-6 rounded-xl font-bold text-xl lg:text-2xl hover:shadow-xl hover:shadow-wibby-green/30 transition-all duration-300 transform hover:scale-105"
            onClick={() => scrollToSection('demo-form')}
          >
            🚀 Empezar Ahora por solo $37
          </Button>
        </div>

        {/* Trust Elements */}
        <div className="flex flex-col sm:flex-row justify-center items-center gap-6 text-gray-300">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-wibby-green rounded-full"></div>
            <span>Garantía 30 días</span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-wibby-green rounded-full"></div>
            <span>Sin permanencia</span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 bg-wibby-green rounded-full"></div>
            <span>Cancelación inmediata</span>
          </div>
        </div>
      </div>
    </section>
  );
}